You are updating the humor evolution guidelines for JESTER AI.
Given a list of success patterns and avoid patterns, create a refined style guide.

Success patterns: {{SUCCESS_PATTERNS}}
Avoid patterns: {{FAIL_PATTERNS}}

Return JSON:
{
  "style_guidelines": [
    "...",
    "..."
  ],
  "high_signal_topics": [
    "...",
    "..."
  ],
  "things_to_avoid": [
    "...",
    "..."
  ]
}
