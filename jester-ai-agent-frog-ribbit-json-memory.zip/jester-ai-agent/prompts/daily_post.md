Create one short, high-quality viral post in English for X (Twitter).

Topic: {{TOPIC}}
Context: {{CONTEXT}}
Recent successful joke patterns: {{SUCCESS_PATTERNS}}
Recent failed patterns: {{FAIL_PATTERNS}}
Recent posts to avoid repeating: {{RECENT_POSTS}}

Constraints:
- Must be <= 240 characters.
- Must be rude, crude, and savage (adult humor allowed).
- Must include ONE swamp/frog reference.
- Must NOT include hashtags.
- Must not mention "OpenAI" or "LLM".
- Must NOT be financial advice.
- Must be highly shareable and punchy, like American X humor.
- EVERY sentence MUST end with " ribbit."

Return ONLY the tweet text. No explanations.
