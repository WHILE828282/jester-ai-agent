# Security Policy

## Reporting a Vulnerability
Please report security issues privately.

## Content Safety Note
This bot is designed for adult, crude humor (profanity allowed).
However, it must still avoid:
- hate speech / slurs against protected groups
- harassment of private individuals
- calls for violence
- sexual content involving minors
- doxxing

Guardrails live in `src/humor/guardrails.ts`.
